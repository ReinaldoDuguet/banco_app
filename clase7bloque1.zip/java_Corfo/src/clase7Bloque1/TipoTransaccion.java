package clase7Bloque1;

public enum TipoTransaccion {
	CARGO, 
	ABONO,
	

}
